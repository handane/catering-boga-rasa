<?php 
   $host = 'localhost';
   $username = 'root';
   $password = '';
   $db = 'joki_cateringbogarasa';

   $conn = mysqli_connect($host, $username, $password, $db);
?>