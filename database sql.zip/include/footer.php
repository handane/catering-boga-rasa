<div class="footer-area xxx">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="footer-box about-widget">
						<h2 style="color: white;" class="widget-title">Tentang Kami</h2>
						<p style="color: white; text-align:justify"><b>Catering Boga Rasa</b> menyajikan masakan rumah yang dimasak segar setiap hari, memastikan hidangan yang selalu fresh dan lezat. Kami berkomitmen untuk memberikan cita rasa autentik dengan bahan-bahan berkualitas, menghadirkan pengalaman kuliner yang memuaskan dan sehat bagi pelanggan.</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 style="color: white;" class="widget-title">Alamat</h2>
						<ul>
							<li>jl. pintu air no.38 jatirahayu, pondok melati, bekasi</li>
							<!-- <li>support@cateringbogarasa.com</li> -->
							<!-- <li>+00 111 222 3333</li> -->
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="footer-box pages">
						<h2 style="color: white;" class="widget-title">Halaman</h2>
						<ul>
							<li><a style="color: white;" href="./">User</a></li>
							<li><a style="color: white;" href="./app/">Admin</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end footer -->

	<!-- copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyright &copy;2024. <a href="#">Catering Boga Rasa</a>
					</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>